// import React from 'react';
// import RecipeCard from './RecipeCard';


// function SearchComponent() {
//     const API_KEY = "dd8ce41e1945432e8073b72bdb95ed95";

//     let recipeList = [
//         { id: 1, name: "Spaghetti Carbonara", ingredients: ["spaghetti", "eggs", "cheese", "bacon"] },
//         { id: 2, name: "Chicken Curry", ingredients: ["chicken", "curry powder", "coconut milk"] },
//         { id: 3, name: "Vegetable Stir Fry", ingredients: ["mixed vegetables", "soy sauce", "ginger"] }
//     ];
//     return(
//         <div>
//         <div className="search-component">
//             <h1>Recipe Finder</h1>
//             <RecipeCard recipe={{ title: "Spaghetti Carbonara", image: "https://example.com/spaghetti.jpg", description: "A classic Italian pasta dish." }} />
//             <RecipeCard recipe={{ title: "Chicken Curry", image: "https://example.com/curry.jpg", description: "A spicy and flavorful dish." }} />
//             <RecipeCard recipe={{ title: "Vegetable Stir Fry", image: "https://example.com/stirfry.jpg", description: "A quick and healthy meal." }} />
//         </div>
//         </div>
//     );
// }

// export default SearchComponent;